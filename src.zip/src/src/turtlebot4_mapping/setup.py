from setuptools import find_packages, setup

package_name = 'turtlebot4_mapping'

setup(
    name=package_name,
    version='0.0.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name + '/launch', ['launch/turtlebot4_mapping.launch.py', 'launch/navigation_with_local.launch.py', 'launch/auto_map.launch.py', 'launch/auto_save.launch.py']),    
        ('share/' + package_name, ['package.xml']),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='vnolas82',
    maintainer_email='vnolas82@todo.todo',
    description='TODO: Package description',
    license='TODO: License declaration',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
        'auto_explore = turtlebot4_mapping.auto_save:main',
        'obsctacle_avoid = my_project.obstacle_avoid:main',
        'esp32_goal = turtlebot4_mapping.esp32_goal:main',
        'move = turtlebot4_mapping.move_to_position:main',
        ],
    },
)
