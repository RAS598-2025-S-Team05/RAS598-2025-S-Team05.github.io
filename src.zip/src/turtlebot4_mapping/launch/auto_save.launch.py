from launch import LaunchDescription
from launch.actions import ExecuteProcess
import os

def generate_launch_description():

    save_path = os.path.expanduser('~/ros2_ws/src/turtlebot4_mapping/maps/my_map')

    return LaunchDescription([
        ExecuteProcess(
            cmd=[
                'ros2', 'run', 'nav2_map_server', 'map_saver_cli',
                '--ros-args', '--remap', 'map:=/rpi_07/map',
                '--', '-f', save_path
            ],
            output='screen'
        )
    ])
