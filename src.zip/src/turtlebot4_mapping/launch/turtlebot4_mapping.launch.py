from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, IncludeLaunchDescription
from launch.substitutions import LaunchConfiguration, TextSubstitution
from launch_ros.actions import Node
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch_ros.substitutions import FindPackageShare
import os

def generate_launch_description():
    namespace = LaunchConfiguration('namespace')
    model = LaunchConfiguration('model')

    turtlebot4_navigation_launch_dir = os.path.join(
        FindPackageShare('turtlebot4_navigation').find('turtlebot4_navigation'),
        'launch'
    )

    turtlebot4_viz_launch_dir = os.path.join(
        FindPackageShare('turtlebot4_viz').find('turtlebot4_viz'),
        'launch'
    )

    return LaunchDescription([
        # Declare launch arguments
        DeclareLaunchArgument(
            'namespace',
            default_value=TextSubstitution(text='/rpi_07'),
            description='Robot namespace'
        ),
        DeclareLaunchArgument(
            'model',
            default_value=TextSubstitution(text='lite'),
            description='Robot model'
        ),

        # Launch SLAM (Mapping)
        IncludeLaunchDescription(
            PythonLaunchDescriptionSource(
                os.path.join(turtlebot4_navigation_launch_dir, 'slam.launch.py')
            ),
            launch_arguments={
                'namespace': namespace,
                'sync': TextSubstitution(text='false'),
                'use_sim_time': TextSubstitution(text='false'),
            }.items()
        ),

        # Launch RViz for Visualization
        IncludeLaunchDescription(
            PythonLaunchDescriptionSource(
                os.path.join(turtlebot4_viz_launch_dir, 'view_robot.launch.py')
            ),
            launch_arguments={
                'namespace': namespace,
                'model': model
            }.items()
        ),

        # Launch teleop_twist_keyboard
        Node(
            package='teleop_twist_keyboard',
            executable='teleop_twist_keyboard',
            name='teleop_keyboard',
            output='screen',
            prefix='xterm -e',  # open new xterm window
            remappings=[
                ('/cmd_vel', [namespace, '/cmd_vel'])
            ]
        ),
    ])

