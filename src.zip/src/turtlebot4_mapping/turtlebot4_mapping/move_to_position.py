#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from geometry_msgs.msg import PoseStamped
from nav2_simple_commander.robot_navigator import BasicNavigator
from tf_transformations import euler_from_quaternion, quaternion_from_euler
import tf2_ros
from tf2_geometry_msgs import do_transform_pose
from geometry_msgs.msg import TransformStamped
import math

class RelativeNavigator(Node):
    def __init__(self):
        super().__init__('relative_navigator')

        self.navigator = BasicNavigator()
        self.navigator.waitUntilNav2Active()

        # Define goal relative to robot's current pose
        relative_x = 2.0  # meters forward
        relative_y = 1.0  # meters left
        relative_yaw_deg = 0.0  # face forward

        # Get robot's current pose in map frame
        tf_buffer = tf2_ros.Buffer()
        tf_listener = tf2_ros.TransformListener(tf_buffer, self)

        self.get_logger().info("Waiting for transform from base_link to map...")
        tf_buffer.can_transform('map', 'base_link', rclpy.time.Time(), timeout=rclpy.duration.Duration(seconds=10.0))

        transform: TransformStamped = tf_buffer.lookup_transform('map', 'base_link', rclpy.time.Time())
        self.get_logger().info("Transform received.")

        # Create relative pose in base_link frame
        relative_pose = PoseStamped()
        relative_pose.header.frame_id = 'base_link'
        relative_pose.header.stamp = self.get_clock().now().to_msg()
        relative_pose.pose.position.x = relative_x
        relative_pose.pose.position.y = relative_y
        relative_pose.pose.position.z = 0.0

        # Set orientation (quaternion)
        yaw_rad = math.radians(relative_yaw_deg)
        q = quaternion_from_euler(0, 0, yaw_rad)
        relative_pose.pose.orientation.x = q[0]
        relative_pose.pose.orientation.y = q[1]
        relative_pose.pose.orientation.z = q[2]
        relative_pose.pose.orientation.w = q[3]

        # Transform relative pose to map frame
        goal_pose = do_transform_pose(relative_pose, transform)
        goal_pose.header.frame_id = 'map'
        goal_pose.header.stamp = self.get_clock().now().to_msg()

        self.get_logger().info(f"Sending goal: x={goal_pose.pose.position.x:.2f}, y={goal_pose.pose.position.y:.2f}")
        self.navigator.goToPose(goal_pose)

        while not self.navigator.isTaskComplete():
            feedback = self.navigator.getFeedback()
            if feedback:
                self.get_logger().info(f'Distance remaining: {feedback.distance_remaining:.2f} m')

        result = self.navigator.getResult()
        self.get_logger().info(f'Navigation result: {result}')

def main(args=None):
    rclpy.init(args=args)
    node = RelativeNavigator()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

