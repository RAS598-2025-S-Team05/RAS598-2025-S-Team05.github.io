#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from geometry_msgs.msg import PoseWithCovarianceStamped
from std_msgs.msg import Header

class InitialPosePublisher(Node):
    def __init__(self):
        super().__init__('initial_pose_publisher')
        self.publisher = self.create_publisher(PoseWithCovarianceStamped, '/rpi_07/initialpose', 10)
        self.timer = self.create_timer(5.0, self.publish_initial_pose)

    def publish_initial_pose(self):
        pose = PoseWithCovarianceStamped()
        pose.header = Header()
        pose.header.stamp = self.get_clock().now().to_msg()
        pose.header.frame_id = "map"

        pose.pose.pose.position.x = 0.0
        pose.pose.pose.position.y = 0.0
        pose.pose.pose.orientation.z = 0.0
        pose.pose.pose.orientation.w = 1.0

        pose.pose.covariance = [0.25, 0, 0, 0, 0, 0,
                                0, 0.25, 0, 0, 0, 0,
                                0, 0, 0.0, 0, 0, 0,
                                0, 0, 0, 0.0, 0, 0,
                                0, 0, 0, 0, 0.0, 0,
                                0, 0, 0, 0, 0, 0.068]

        self.publisher.publish(pose)
        self.get_logger().info('Initial pose published.')
        self.destroy_node()

def main(args=None):
    rclpy.init(args=args)
    node = InitialPosePublisher()
    rclpy.spin(node)
    rclpy.shutdown()

if __name__ == '__main__':
    main()

