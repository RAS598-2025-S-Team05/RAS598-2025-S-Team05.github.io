import rclpy
from rclpy.node import Node
from my_messages.srv import MySrv
from std_msgs.msg import String  # Standard message type for publishing results

class MyClient(Node):
    def __init__(self):
        super().__init__('my_client')

        # Create a service client for /danaukes/service
        self.client = self.create_client(MySrv, '/danaukes/service')

        # Publisher to /<your-asurite>/service_result
        self.publisher = self.create_publisher(String, '/vnolas82/service_result', 10)

        # Timer to send requests every 5 seconds
        self.timer = self.create_timer(5.0, self.send_request)

    def send_request(self):
        """ Function to send a service request at regular intervals """
        if not self.client.service_is_ready():
            self.get_logger().info('Waiting for service...')
            return

        self.request = MySrv.Request()
        self.request.my_string_in = 'vnolas82'  # Sending ASURITE ID as input
        self.future = self.client.call_async(self.request)
        self.future.add_done_callback(self.callback)

    def callback(self, future):
        """ Callback function to process the service response and publish it """
        try:
            response = future.result()
            self.get_logger().info(f'Service response: {response.my_string_out}')

            # Publish response to /vnolas82/service_result
            msg = String()
            msg.data = response.my_string_out
            self.publisher.publish(msg)
            self.get_logger().info(f'Published response to /vnolas82/service_result')

        except Exception as e:
            self.get_logger().error(f'Service call failed: {e}')

def main(args=None):
    rclpy.init(args=args)
    node = MyClient()
    rclpy.spin(node)  # Keep running indefinitely
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()

