import rclpy
from rclpy.node import Node
from my_messages.msg import MyMsg

class MyPublisher(Node):
    def __init__(self):
        super().__init__('my_publisher')
        self.publisher = self.create_publisher(MyMsg, '/vnolas82/topic', 10)
        self.timer = self.create_timer(1.0, self.publish_message)

    def publish_message(self):
        msg = MyMsg()
        msg.my_int = 42
        msg.my_float = 3.14
        msg.my_string = 'Hello, ROS 2!'
        msg.my_bool = True
        self.publisher.publish(msg)
        self.get_logger().info('Welcome to ROS2!')

def main(args=None):
    rclpy.init(args=args)
    node = MyPublisher()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()

