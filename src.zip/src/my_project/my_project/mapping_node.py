from launch import LaunchDescription
from launch.actions import TimerAction, Shutdown, IncludeLaunchDescription
from launch_ros.actions import Node
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch_ros.substitutions import FindPackageShare
import os

def generate_launch_description():
    namespace = 'rpi_07'
    model = 'lite'

    # Find paths
    nav_launch_dir = os.path.join(
        FindPackageShare('turtlebot4_navigation').perform({}),
        'launch'
    )
    viz_launch_dir = os.path.join(
        FindPackageShare('turtlebot4_viz').perform({}),
        'launch'
    )

    # SLAM and RViz
    slam = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(os.path.join(nav_launch_dir, 'slam.launch.py')),
        launch_arguments={
            'sync': 'false',
            'namespace': namespace
        }.items()
    )

    rviz = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(os.path.join(viz_launch_dir, 'view_robot.launch.py')),
        launch_arguments={
            'namespace': namespace,
            'model': model
        }.items()
    )

    # Mapping node (your node, just prints status)
    mapping_node = Node(
        package='my_project',
        executable='mapping_node',
        name='mapping_node',
        output='screen'
    )

    # Optional: small forward movement for autonomous mapping (uncomment if needed)
    # dummy_mover = Node(
    #     package='demo_nodes_cpp',
    #     executable='talker',
    #     name='fake_mover'
    # )

    # Shutdown after 5 seconds
    shutdown = TimerAction(
        period=5.0,
        actions=[Shutdown()]
    )

    return LaunchDescription([
        slam,
        rviz,
        mapping_node,
        # dummy_mover,
        shutdown
    ])

