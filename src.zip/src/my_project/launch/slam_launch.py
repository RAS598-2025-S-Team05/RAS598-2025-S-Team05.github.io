from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, IncludeLaunchDescription, GroupAction
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration, PathJoinSubstitution
from launch_ros.substitutions import FindPackageShare
from launch_ros.actions import Node


def generate_launch_description():
    namespace = LaunchConfiguration('namespace')

    # Declare the namespace argument
    declare_namespace = DeclareLaunchArgument(
        'namespace',
        default_value='rpi_07',
        description='Namespace for the robot nodes'
    )

    # Launch view_robot from turtlebot4_viz
    view_robot_launch = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            PathJoinSubstitution([
                FindPackageShare('turtlebot4_viz'),
                'launch',
                'view_robot.launch.py'
            ])
        ),
        launch_arguments={
            'namespace': namespace,
            'model': 'lite'
        }.items()
    )

    # SLAM Toolbox Node
    slam_toolbox_node = Node(
        package='slam_toolbox',
        executable='sync_slam_toolbox_node',
        name='slam_toolbox',
        namespace=namespace,
        output='screen',
        parameters=[
            {'use_sim_time': False},
            PathJoinSubstitution([
                FindPackageShare('turtlebot4_navigation'),
                'config',
                'mapper_params_online_sync.yaml'
            ])
        ],
        remappings=[
            ('scan', '/scan'),
            ('odom', '/rpi_07/odom')
        ]
    )

    # Static TF: base_link -> rplidar_link
    static_tf_rplidar = Node(
        package='tf2_ros',
        executable='static_transform_publisher',
        arguments=['0', '0', '0', '0', '0', '0', 'base_link', 'rplidar_link']
    )

    # Static TF: odom -> base_link
    static_tf_odom = Node(
        package='tf2_ros',
        executable='static_transform_publisher',
        arguments=['0', '0', '0', '0', '0', '0', 'odom', 'base_link']
    )

    # Static TF: map -> odom
    static_tf_map = Node(
        package='tf2_ros',
        executable='static_transform_publisher',
        arguments=['0', '0', '0', '0', '0', '0', 'map', 'odom']
    )

    return LaunchDescription([
        declare_namespace,
        view_robot_launch,
        static_tf_rplidar,
        static_tf_odom,
        static_tf_map,
        slam_toolbox_node
    ])

